package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;

import com.yash.service.MobileCheck;
import com.yash.service.NumberCheck;

class testNumberCheck {
	Answer<Boolean>answer=(invocation)->{
		Object[] args=invocation.getArguments();
		String contact=(String)args[0];
		Pattern compile=Pattern.compile("[6-9][0-9]{9}");
		Matcher matcher=compile.matcher(contact);
		if(matcher.find()) {
			return true;
		}
		return false;
		
		
	};
	@Mock
	private MobileCheck checkMobile;
	@InjectMocks
	private NumberCheck numberCheck;
	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	@DisplayName("Test 01 : Check if mobile number entered is of 10 digits")
	@Test
	void testMobileNumberCheck_Positive() {
		String contactNumber="7799413636";
		when(checkMobile.checkMobileNumber(contactNumber)).then(answer);
		boolean actual=numberCheck.check(contactNumber);
		assertTrue(actual);
		
	}
	@DisplayName("Test 02 : Check if mobile number entered is of 10 digits")
	@Test
	void testExceptionCheck_exception() {
	try {
		String contactNumber="an99413636";
		when(checkMobile.checkMobileNumber(contactNumber))
		.thenThrow(new Exception("Invalid Input:SpecialCharaters not allow"));
		numberCheck.check(contactNumber);
		assertTrue(false);
	
	}catch(Exception e) {
		assertTrue(true);
	}
	}

}
